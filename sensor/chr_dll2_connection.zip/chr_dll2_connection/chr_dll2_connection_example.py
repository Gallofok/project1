# -*- coding: utf-8 -*-
"""
Example programm for communciation with a CHR device

Copyright Precitec Optronik GmbH
"""
#import important libraries
import numpy as np
from matplotlib import pyplot as plt
#establish connection to a CHR device over Ethernet
import chr_dll2_connection as chr_connection
chr = chr_connection.CHR_connection('IP: 192.168.170.2',1)

#Read the spectrum:  0 - raw spectrum; 1 - processed spectrum in confocal mode; 2 - FFT
spectrum = chr.get_spectrum(0)
#plot the spectrum
plt.clf()
plt.subplot(1,2,1)
plt.plot(spectrum)

print(np.mean(spectrum))#print the mean value of the spectrum
res = chr.send_command('$SODX 256')#order the distance 1 signal 
print(res)
res = chr.send_command('$LAI?') # check the lamp intensity
print(res)

#read out the autobuffer. Works only, if some signal is ordered
n_sample = 10000 #buffer size
#create buffer
chr.set_autobuffer_size(n_sample)
chr.flush_autobuffer()    
chr.start_autobuffer()
buffer = chr.read_autobuffer()

#plot the results stored in the autobuffer
plt.subplot(1,2,2)
plt.plot(buffer)
